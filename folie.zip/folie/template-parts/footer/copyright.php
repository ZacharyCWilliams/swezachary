<div id="copyright">
	
	<div class="copyright-content <?php echo esc_attr( codeless_extra_classes( 'copyright_content' ) ) ?>">
        
        <div class="copyright-content-row <?php echo esc_attr( codeless_extra_classes( 'copyright_content_row' ) ) ?>">
            
             <?php codeless_build_copyright() ?>
            
        </div><!-- .copyright-content-row -->
        
    </div><!-- .copyright-content -->


</div>