<?php

extract($element['params']);

?>

<div class="widgetized">

<?php dynamic_sidebar( $widget_sidebar ); ?>

</div>