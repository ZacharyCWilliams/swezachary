<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}


if ( ! class_exists( 'Cl_Shortcode_Container' ) ) {
	
	
	abstract class Cl_Shortcode_Container extends Cl_Shortcode{
	    
	}
	
}
?>