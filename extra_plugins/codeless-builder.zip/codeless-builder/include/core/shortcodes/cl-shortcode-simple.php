<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class Cl_Shortcode_Simple extends Cl_Shortcode {
	
}