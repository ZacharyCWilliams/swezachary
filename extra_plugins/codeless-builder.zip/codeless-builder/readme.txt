# Codeless Builder

## Description


## Changelog

### 1.0

* Released: --, 2018

Initial release

### Other Versions

View on Themeforest

### 2.1.1

* Released: March 28, 2019

Fixed: Builder Elements not working when Customize Posts not active
Added: Readmore file


### 2.1.2

* Released April 3, 2019

Fixed: Urlencode issue with codeless builder URL
Added: Anchor Button to Header Elements Medium Editor


### 2.2

* Released July, 2019

Updated: Now using complete WP controls and settings